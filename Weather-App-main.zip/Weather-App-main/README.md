# Weather App
A simple weather app that allows users to check the current weather conditions of any city and displays information such as temperature, humidity, and wind speed.
